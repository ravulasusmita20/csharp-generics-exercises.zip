namespace GenericsPlayground.Domain
{
    public abstract class Entity
    {
        public int Id { get; set; }
    }
}